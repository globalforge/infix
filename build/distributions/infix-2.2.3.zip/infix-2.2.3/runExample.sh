java -cp antlr4-runtime-4.10.1.jar:fix-2.2.3.jar:infix-2.2.3.jar:slf4j-api-1.7.7.jar:slf4j-simple-1.7.7.jar com.globalforge.infix.example.ExampleApp
